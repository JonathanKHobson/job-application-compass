# Case Card Template

Use this before expanding into a full case study.

```markdown
## [Case Title]

- Target reader:
- Reader speed:
- Case thesis:
- Problem:
- Role:
- Team or collaborators:
- Constraints:
- Methods:
- Artifacts:
- Decision influenced:
- Outcome or learning:
- What this proves:
- Confidentiality:
- Missing proof:
- Do not claim yet:
```

## Completion Check

The case card is strong enough to expand when it has:

- a specific problem
- a defensible contribution
- at least one artifact
- one decision, outcome, or learning
- a confidentiality path
- visible missing proof
