# Portfolio Template Index

Choose the smallest template that fits the task.

| Need | Template |
| --- | --- |
| Full portfolio case study | `case-study.md` |
| One-page project summary | `case-card.md` |
| Caption several artifacts | `artifact-caption-set.md` |
| Prepare an interview presentation | `interview-deck-outline.md` |
| Create a controlled follow-up artifact | `leave-behind.md` |
| Frame AI workflow or automation-adjacent work | `ai-workflow-case.md` |
| Frame UX research, audit, or discovery work | `ux-research-case.md` |

## Default Choice

If evidence is messy, start with `case-card.md`. If the user already has solid facts and artifacts, use `case-study.md`.
