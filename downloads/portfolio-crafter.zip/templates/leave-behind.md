# Leave-Behind Template

Use this for a controlled one-page follow-up artifact after an interview, referral, or hiring conversation.

```markdown
# [Case Title] Leave-Behind

## Why This Case Matters For [Role/Team]

## Problem

## My Contribution

## Key Artifact
- Caption:
- Alt text:
- Redaction notes:

## Decision Or Outcome

## What I Would Bring To This Role

## Confidentiality Notes

## Missing Or Withheld Details
```

## Guardrails

- Keep it short.
- Do not include private screenshots or data.
- Do not add new unsupported claims after the interview.
- Use redacted or abstracted artifacts when needed.
