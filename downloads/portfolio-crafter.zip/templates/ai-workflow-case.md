# AI Workflow Case Template

Use this for AI workflow, prompt-system, automation-adjacent, or tool-assisted work. Keep claims practical and evidence-bound.

```markdown
# [AI Workflow Case Title]

## Case Thesis
This case shows how I used [workflow/tool/prompt/system] to address [problem] while preserving [guardrail/evaluation/human review].

## Problem
- Workflow pain:
- User or team need:
- Risk:

## My Contribution
- System or workflow design:
- Prompt, rubric, or guardrail work:
- Evaluation or review method:
- Handoff or adoption support:

## Key Artifacts
- [Artifact]:
  - Caption:
  - Decision influenced:
  - Redaction notes:

## Outcome Or Learning
[Use verified outcome, observed learning, or non-numeric impact.]

## Guardrails
- Human review:
- Evidence boundary:
- Automation boundary:
- What was not automated:

## What This Proves

## Evidence Gaps
- [MISSING INFO: ...]
```

## Avoid

- Claiming model expertise without evidence.
- Claiming production impact from prototypes.
- Hiding evaluation limits.
- Suggesting stealth automation or unsupported decision authority.
