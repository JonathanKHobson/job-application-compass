# Case Study Template

```markdown
# [Case Study Title]

## Case Thesis
[This case shows ...]

## Context
- Project:
- Target reader:
- Role:
- Team or collaborators:
- Timeline:
- Constraints:
- Confidentiality:

## Problem
[Describe the problem, audience, stakes, and constraint.]

## My Contribution
[Describe what the candidate personally did. Separate team work from individual work.]

## Process And Decisions
1. [Method or artifact]
   - Why it was used:
   - What it revealed:
   - Decision influenced:

2. [Method or artifact]
   - Why it was used:
   - What it revealed:
   - Decision influenced:

## Key Artifacts

### [Artifact]
- Caption:
- Alt text:
- Redaction notes:

## Outcome Or Learning
[Use verified metric, transparent estimate, or non-numeric impact.]

## What This Proves
[Connect the case to reader needs.]

## Confidentiality And Redaction Notes
- Share status:
- Details to remove:
- Safe abstraction:
- Permission needed:

## Evidence Gaps
- [MISSING INFO: ...]
```
