# Interview Deck Outline Template

Use this when a case needs live presentation or interview continuity. This is an outline, not a designed deck.

```markdown
# [Case] Interview Deck Outline

## Slide 1: Role Problem
- Claim:
- Visual:
- Speaker note:

## Slide 2: Context And Constraint
- Claim:
- Visual:
- Speaker note:

## Slide 3: My Contribution
- Claim:
- Visual:
- Speaker note:

## Slide 4: Evidence And Artifact
- Claim:
- Visual:
- Speaker note:

## Slide 5: Decision Or Outcome
- Claim:
- Visual:
- Speaker note:

## Slide 6: Transfer To Target Role
- Claim:
- Visual:
- Speaker note:

## Appendix
- Evidence notes:
- Redaction notes:
- Metrics status:
- Questions to prepare:
```

## Questions To Prepare

- What exactly was your role?
- What changed because of the work?
- What evidence supports that?
- What would you do differently now?
- What cannot be shared publicly?
