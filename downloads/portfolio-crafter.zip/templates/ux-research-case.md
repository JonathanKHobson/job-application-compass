# UX Research Case Template

Use this for UX research, heuristic audit, discovery, prototype evaluation, or research-to-product decision work.

```markdown
# [UX Research Case Title]

## Case Thesis
This case shows how I used [method/artifact] to clarify [problem/risk] and influence [decision].

## Context
- Product or domain:
- Target users:
- Role:
- Constraints:
- Confidentiality:

## Research Or Evaluation Problem

## My Contribution
- Methods:
- Participants or evidence type:
- Analysis approach:
- Artifacts produced:

## Findings Or Signals
1. [Finding]
   - Evidence:
   - Decision relevance:

2. [Finding]
   - Evidence:
   - Decision relevance:

## Decision Influenced

## Outcome Or Learning

## Key Artifacts
- [Artifact]:
  - Caption:
  - Alt text:
  - Redaction notes:

## What This Proves

## Evidence Gaps
- [MISSING INFO: ...]
```

## Avoid

- Claiming user research when only heuristic review was supplied.
- Claiming shipped outcome when only recommendation or prototype evidence exists.
- Publishing participant detail without permission.
