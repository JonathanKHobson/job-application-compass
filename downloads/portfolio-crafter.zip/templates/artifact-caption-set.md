# Artifact Caption Set Template

```markdown
# Artifact Caption Set

## Context
- Case:
- Target reader:
- Format:
- Confidentiality:

## Captions

### [Artifact 1]
- Artifact type:
- Caption: [Artifact] shows [what it shows] and matters because [why it mattered]. Decision influenced: [decision].
- Alt text:
- Use context:
- Redaction notes:
- Missing context:

### [Artifact 2]
- Artifact type:
- Caption:
- Alt text:
- Use context:
- Redaction notes:
- Missing context:

## Caption Risks
- Unsupported outcome:
- Confidential detail:
- Missing decision:
- Missing alt text:
```

## Rule

If the caption cannot name what the artifact shows, why it mattered, and which decision it influenced, mark the gap instead of inventing context.
