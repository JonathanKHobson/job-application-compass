# Case Study Structure

A strong case study is a sequence of proof, not a chronological diary.

## Recommended Structure

```markdown
# [Case Study Title]

## Case Thesis
[One or two sentences on what this case proves.]

## Context
- Project:
- Role:
- Team or collaborators:
- Timeline:
- Constraints:

## Problem
[The user, business, workflow, learning, or product problem.]

## My Contribution
[What the candidate personally did, with boundaries.]

## Process And Decisions
[Methods, artifacts, decisions, and tradeoffs.]

## Key Artifacts
[Captioned artifacts or placeholders.]

## Outcome Or Learning
[Verified outcome, transparent estimate, or non-numeric impact.]

## What This Proves
[Why the case matters for the target reader.]

## Confidentiality And Redaction Notes

## Evidence Gaps
```

## Section Guidance

### Case Thesis

Name the capability and proof path. Avoid "This project was about..." when the case can say what it proves.

### Context

Include only context needed to understand the work. Do not reveal private client, user, institutional, or internal details unless the user confirms they are shareable.

### Problem

A useful problem includes friction, stakes, audience, and constraint. If stakes are unknown, mark `[MISSING INFO: stakes]`.

### My Contribution

Use "I" for the candidate's work and "we" for team work. Do not blur the boundary.

### Process And Decisions

Emphasize decision quality over exhaustive process. Show why a method was used and what it changed.

### Key Artifacts

Every artifact needs:

- what it is
- what it shows
- why it mattered
- which decision it influenced
- alt text
- confidentiality status

### Outcome Or Learning

Outcomes may be numeric, qualitative, decision-based, or learning-based. Do not invent results. If the outcome is unknown, use honest language:

```text
The project clarified [decision/risk/next step], but the final outcome was not supplied.
```

## Length Guidance

- Case card: one screen or one page.
- Short case study: 600-900 words.
- Deep case study: 1,200-1,800 words plus appendix.
- Interview deck outline: 5-7 slides plus appendix.

Shorter is better when evidence is thin.
