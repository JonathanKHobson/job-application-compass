# Artifact Captions

Artifact captions bridge visuals and proof. They should make the artifact useful even when the reviewer skims.

## Caption Formula

```text
[Artifact] shows [what it shows] and matters because [why it mattered]. Decision influenced: [decision].
```

## Required Fields

For each artifact, capture:

- artifact name
- artifact type
- what it shows
- why it mattered
- decision influenced
- alt text
- use context
- confidentiality status
- missing context

## Caption Examples

Generic supported caption:

```text
[Research synthesis board] shows how open-ended responses were clustered into decision themes and matters because it helped the team prioritize the next discovery questions. Decision influenced: [MISSING INFO: exact decision].
```

Generic design caption:

```text
[Prototype screen] shows the revised entry flow and matters because it made the key action, error state, and next step easier to evaluate. Decision influenced: [MISSING INFO: review or launch decision].
```

Generic workflow caption:

```text
[Workflow map] shows where handoffs, dependencies, and review steps occurred and matters because it made the operational bottleneck visible. Decision influenced: [MISSING INFO: process change].
```

## Alt Text

Alt text should describe what is visible, not sell the candidate.

Use:

```text
Diagram showing [main visual elements] connected by [relationship or flow].
```

Avoid:

```text
Beautiful portfolio artifact proving strategic excellence.
```

## Missing Context

If any required field is absent, return:

```text
[MISSING INFO: artifact context needed before captioning]
```

Do not invent a decision, user outcome, or metric to make the caption feel complete.

## Caption Audit

Flag captions that:

- describe the artifact but not why it mattered
- imply a result without support
- expose sensitive internal detail
- lack alt text
- sound like a generic project label
