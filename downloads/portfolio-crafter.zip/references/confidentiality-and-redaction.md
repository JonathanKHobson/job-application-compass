# Confidentiality And Redaction

Portfolio work often sits near sensitive project, client, user, or employer material. Treat confidentiality as a drafting constraint, not an afterthought.

## Confidentiality Labels

Use these labels when reviewing a case or artifact:

- `public`: safe to share as written.
- `redacted`: usable after names, screenshots, data, or internal details are removed.
- `private`: useful for prep or internal planning, not public sharing.
- `do_not_share`: blocked from public case studies, leave-behinds, decks, and captions.
- `unknown`: do not publish until reviewed.

## Redaction Targets

Check for:

- client, employer, institution, vendor, or partner names
- private product names
- user names, participant details, quotes, or screenshots
- internal roadmaps, strategy, data, or financials
- analytics dashboards or exact metrics
- unreleased product visuals
- proprietary process details
- security, credentials, or access information

## Safe Abstraction Pattern

When details are sensitive, generalize without changing the claim:

```text
For an education product team, I helped evaluate [problem] using [method] and translated findings into [decision/artifact].
```

Do not over-generalize so far that the case becomes meaningless.

## Redaction Notes

Every sensitive case should include:

```markdown
## Confidentiality And Redaction Notes
- Share status:
- Details to remove:
- Safe abstraction:
- Permission needed:
- Do not claim:
```

## Blocked Content

Block or mark for redaction when the case includes:

- private user data
- confidential screenshots
- internal metrics without permission
- unreleased strategy
- claims that cannot be separated from sensitive evidence

Return:

```text
[MISSING INFO: permission or redaction plan needed before sharing]
```

## Public Website Boundary

Do not create, publish, or imply a public website. This skill may draft case-study text, case cards, caption sets, leave-behinds, and deck outlines. Website planning requires an explicit user request.
