# Generic Phrase Guardrails

Use this file to remove generic portfolio language and replace it with evidence.

## Phrases To Challenge

Challenge phrases like:

- `transformed the user experience`
- `drove strategic impact`
- `leveraged insights`
- `created meaningful change`
- `delivered innovative solutions`
- `improved engagement`
- `streamlined the process`
- `enhanced usability`
- `aligned stakeholders`
- `data-driven approach`
- `end-to-end ownership`
- `cross-functional collaboration`
- `high-impact design`
- `actionable insights`

These phrases are not banned. They need proof.

## Replacement Questions

Ask:

- What artifact shows this?
- What decision changed?
- What was the constraint?
- What did the candidate personally do?
- What did the team do?
- What is the verified outcome?
- What is still missing?

## Better Pattern

Weak:

```text
Delivered actionable insights that transformed the product strategy.
```

Stronger:

```text
Grouped [evidence type] into [themes] so the team could decide whether to prioritize [decision]. [MISSING INFO: final decision or outcome.]
```

Weak:

```text
Owned the end-to-end redesign.
```

Stronger:

```text
Led [specific part] of the redesign, including [artifact/method], while collaborating with [team or role] on [shared work].
```

## AI-Sludge Check

A case may sound AI-polished if it:

- uses big claims without concrete artifacts
- repeats "strategic", "innovative", or "impactful"
- hides uncertainty
- removes missing-info markers too early
- makes every project sound equally successful

Make the writing more specific, not more dramatic.
