# Portfolio Quality Rubric

Use this rubric to audit a case study, case card, artifact caption set, or portfolio draft.

## Snapshot

- Target reader:
- Reader speed:
- Format:
- Overall read:
- Strongest proof:
- Biggest risk:

## Rubric

Rate each dimension as `strong`, `needs_review`, or `missing`.

| Dimension | Strong Means | Common Risk |
| --- | --- | --- |
| Reader fit | The case makes sense for the target role or reviewer. | Interesting project, unclear relevance. |
| Case thesis | The opening states what the case proves. | Generic "project overview" opening. |
| Problem clarity | The problem is specific and constrained. | Vague transformation language. |
| Contribution | The candidate's role is explicit and defensible. | Implied sole ownership or hidden team work. |
| Methods | Methods are named only when actually used. | Method stuffing. |
| Artifacts | Artifacts show work, decisions, or evidence. | Decorative screenshots without proof. |
| Decisions | The case names what the work influenced. | Process dump with no consequence. |
| Outcomes | Outcomes are verified, estimated, or framed as learning. | Invented or inflated metrics. |
| Confidentiality | Sensitive details are redacted or marked. | Publishing private or client-sensitive details. |
| Accessibility | Captions, alt text, hierarchy, and readability are present. | Visuals without explanation. |
| Voice | Specific, concrete, and human. | Generic AI-polished language. |

## Audit Output

```markdown
## Portfolio Health Snapshot
- Target reader:
- Reader speed:
- Overall read:
- Top priority:
- Biggest risk:

## Findings
1. Issue:
   - Why it matters:
   - Fix:

## Keep

## Cut Or Verify

## Next Revision Pass
```

## Ready Standard

A case is ready for human review when:

- the thesis is clear
- the contribution is defensible
- artifacts are captioned
- sensitive material is handled
- metrics are verified or safely phrased
- missing proof is visible
- the reader can understand fit quickly
