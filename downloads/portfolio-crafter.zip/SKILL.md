---
name: portfolio-crafter
description: Build, edit, target, audit, and sharpen portfolio case studies with evidence-backed claims, artifact captions, confidentiality checks, and reader-aware structure.
compatibility: Claude Desktop, Claude Code, Codex, ChatGPT, and other hosts that can use Markdown skills
---

# Portfolio Crafter

Portfolio Crafter helps a host AI turn real project material into clear, truthful, reader-aware portfolio case studies. Use it for full case studies, targeted rewrites, case cards, artifact captions, portfolio audits, confidentiality review, metric-safe impact language, and interview or deck story continuity.

This skill is public-facing and generic. It must not rely on a private profile, private source register, local file path, personal career history, hidden application packet, or unpublished project evidence.

## Use This Skill When

- The user wants to build a portfolio case study from raw project notes, artifacts, screenshots, research summaries, or a rough draft.
- The user wants to convert a rough project into a one-page case card.
- The user wants to rewrite a generic case-study opening into a role-relevant thesis.
- The user wants artifact captions from supplied facts.
- The user wants to target an existing case study to a role, reader, or portfolio format.
- The user wants to audit a case study for generic language, unclear ownership, missing proof, weak outcomes, or confidentiality risk.
- The user asks how to handle missing, uncertain, sensitive, or unsupported metrics.
- The user needs a case to connect to interview or deck talking points.

## First Move

Identify the task type before writing:

1. Full portfolio case-study build
2. Targeted case-study rewrite
3. Case-card creation
4. Artifact caption writing
5. Portfolio or case audit
6. Confidentiality and redaction review
7. Metrics and unsupported-claim review
8. Interview or deck story continuity from a case

If the user provided enough material, proceed. If a missing fact would change the output materially, ask for that fact or mark it as `[MISSING INFO: ...]`.

## Core Rules

- Treat a portfolio as a proof system, not a gallery.
- Do not invent projects, employers, institutions, clients, users, team size, dates, tools, research methods, metrics, artifacts, decisions, outcomes, ownership, or permissions.
- Preserve truth while improving focus, structure, hierarchy, and reader fit.
- Start with the target reader and reader speed: 10-second scan, 2-5 minute review, or deep interview review.
- Build case studies around problem, role, constraints, methods, artifacts, decisions, outcomes, and what the case proves.
- Use metrics only when supplied and verified. Otherwise use transparent estimates or non-numeric impact language.
- Mark confidential, private, or sensitive artifacts for redaction before turning them into public copy.
- Keep missing proof visible as `[MISSING INFO: ...]`.
- Do not build or imply a public website unless the user explicitly asks for website planning.

## Default Workflow

1. Define the target: reader, role, format, reader speed, and sharing context.
2. Inventory evidence: project facts, artifacts, constraints, methods, decisions, outcomes, metrics, permissions, and unknowns.
3. Choose the case thesis: what this project proves about the candidate's judgment and contribution.
4. Draft or revise: structure the case for scanability, proof, and defensibility.
5. Audit: check ownership, evidence, metrics, confidentiality, accessibility, and generic language.
6. Return next actions: what to verify, redact, source, caption, or cut before sharing.

## Output Shapes

For a full case study, use:

```markdown
# [Case Study Title]

## Case Thesis
[What this project proves for the target reader.]

## Context
- Project:
- Role:
- Team or collaborators:
- Timeline:
- Constraints:

## Problem

## What I Did

## Key Artifacts

## Decisions Influenced

## Outcome Or Learning

## What This Proves

## Confidentiality And Redaction Notes

## Evidence Gaps
```

For a case card, return:

```markdown
## [Case Title]
- Reader hypothesis:
- Problem:
- Role:
- Methods:
- Artifacts:
- Decision influenced:
- Outcome or learning:
- What this proves:
- Confidentiality:
- Missing proof:
```

For artifact captions, return:

```markdown
## Artifact Captions

### [Artifact Name]
- Caption: [Artifact] shows [what it shows] and matters because [why it mattered]. Decision influenced: [decision].
- Alt text:
- Use in:
- Redaction notes:
- Missing context:
```

For an audit, return:

```markdown
## Portfolio Health Snapshot
- Target reader:
- Reader speed:
- Overall read:
- Top priority:
- Biggest risk:

## Findings
1. Issue:
   - Why it matters:
   - Fix:

## Strongest Existing Material

## Next Revision Pass
```

## Reference Navigation

| Need | Read |
| --- | --- |
| Choose the right portfolio workflow and framework | `references/patterns.md` |
| Audit case-study quality | `references/portfolio-quality-rubric.md` |
| Structure a full case study | `references/case-study-structure.md` |
| Turn supplied evidence into a case | `references/evidence-to-case.md` |
| Write artifact captions | `references/artifact-captions.md` |
| Handle confidentiality and redaction | `references/confidentiality-and-redaction.md` |
| Handle metrics, evidence, and missing proof | `references/metrics-and-truth.md` |
| Remove generic language | `references/generic-phrase-guardrails.md` |
| Choose a template | `templates/template-index.md` |
| Use optional specialist roles | `agents/agent.md` |

## Agent Roles

Use the agent files as prompt-role guidance when a portfolio task benefits from focused review:

- `agents/portfolio-strategist.md`: reader, format, case selection, and portfolio narrative
- `agents/case-study-writer.md`: full case-study structure and rewrite
- `agents/artifact-caption-editor.md`: captions, alt text, and artifact proof
- `agents/evidence-integrity-reviewer.md`: unsupported claim and metric checks
- `agents/confidentiality-auditor.md`: redaction, sensitivity, and share-readiness

## Stop Conditions

A portfolio case is ready for the next human review when:

- The target reader and format are clear.
- The case thesis is specific and role-relevant.
- The candidate's contribution is explicit without overstating ownership.
- Every strong claim is supported by supplied evidence.
- Metrics are verified, clearly estimated, or replaced with non-numeric language.
- Artifacts have captions, alt text, and confidentiality notes.
- Missing proof remains visible.
- Generic filler has been replaced with artifacts, decisions, constraints, outcomes, or learning.
