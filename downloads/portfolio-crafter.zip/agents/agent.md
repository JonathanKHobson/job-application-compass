# Portfolio Crafter Agent Roles

These files are prompt-role guidance for a host AI. They are not executable agents.

Use them when a portfolio task needs focused review:

- `portfolio-strategist.md`: reader, format, case selection, and portfolio narrative.
- `case-study-writer.md`: full case-study drafting and rewrite.
- `artifact-caption-editor.md`: captions, alt text, and artifact proof.
- `evidence-integrity-reviewer.md`: unsupported claim, ownership, and metric checks.
- `confidentiality-auditor.md`: redaction, sensitivity, and share-readiness.

## Handoff Rule

Each role should preserve visible gaps. Do not turn `[MISSING INFO: ...]` into polished claims.
