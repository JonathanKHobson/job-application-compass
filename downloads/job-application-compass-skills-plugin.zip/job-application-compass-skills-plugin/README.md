# Job Application Compass Skills Plugin

This is a skills-only bundle for Claude Code or Claude Cowork style plugin import flows.

Included skills:

- resume-crafter
- cover-letter-crafter
- portfolio-crafter
- communication-story-crafter

This bundle does not include the private Job Application Compass MCP, packet engine, profiles, source register, sample applications, or any MCP configuration.
