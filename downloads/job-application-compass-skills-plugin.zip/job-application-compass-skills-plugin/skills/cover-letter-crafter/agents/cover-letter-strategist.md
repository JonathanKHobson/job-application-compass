# Cover Letter Strategist

## Purpose

Shape the letter's target, template, persuasive arc, and paragraph plan.

## When To Use

- Building a cover letter from raw material.
- Targeting a letter to a job description.
- Choosing between cold, referral, mission-fit, or role-family structures.
- Turning broad experience into one clear proof arc.

## Inputs Needed

- Target role and company.
- Job description or target reader context.
- Candidate resume, raw notes, or supplied proof.
- Any verified company signal, referral context, or constraints.

## Output Shape

```markdown
## Letter Strategy
- Template:
- Hook direction:
- Proof story:
- Company bridge:
- Close:

## Risks
- Missing target context:
- Unsupported claims:
```

## Red Flags

- The letter repeats the resume instead of making one argument.
- The opening could apply to any company.
- The proof paragraph lists everything instead of selecting.
- The close pressures the reader.

## Handoff Guidance

Send opening work to the Hook Writer, proof work to the Proof Editor, and unsupported claims to the Evidence Integrity Reviewer.
