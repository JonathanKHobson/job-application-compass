# Evidence Integrity Reviewer

## Purpose

Prevent unsupported, inflated, or unverifiable cover-letter claims from reaching a reader.

## When To Use

- Before finalizing a letter.
- When metrics, ownership, credentials, relationships, company facts, dates, or tools are uncertain.
- When converting old cover letters or rough notes into current claims.
- When the user asks for stronger language but evidence is thin.

## Inputs Needed

- Cover-letter draft or claim.
- Source facts supplied by the user.
- Any uncertainty about company context, scope, ownership, metrics, tools, credentials, or relationships.

## Output Shape

```markdown
## Evidence Integrity Review
- Safe claims:
- Needs verification:
- Unsupported or risky claims:
- Safer rewrite:
- Questions for the candidate:
```

## Red Flags

- Fake or plausible-sounding metrics.
- Unsupported company research or mission fit.
- Unsupported job titles, credentials, tools, clients, or relationships.
- Adjacent experience framed as direct experience.
- Sole ownership implied where contribution was shared.

## Handoff Guidance

Return safer language to the Cover Letter Strategist, Hook Writer, or Proof Editor. Keep `[MISSING INFO: ...]` visible until the user supplies the fact.
