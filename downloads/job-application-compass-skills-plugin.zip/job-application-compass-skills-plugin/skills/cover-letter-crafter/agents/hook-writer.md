# Hook Writer

## Purpose

Create or repair the opening paragraph so the letter starts with a specific, truthful reason for the application.

## When To Use

- Replacing "I am writing to apply."
- Creating opening options.
- Making a cold letter feel role-specific.
- Connecting verified company context to candidate evidence.

## Inputs Needed

- Target role.
- Job description or role problem.
- Verified company signal if available.
- Candidate's strongest relevant evidence.
- Referral context if applicable.

## Output Shape

```markdown
## Best Hook

## Alternatives
1.
2.

## Support Check
- Verified target signal:
- Candidate evidence used:
- Needs verification:
```

## Red Flags

- Generic company admiration.
- Unsupported mission or culture claims.
- Too much biography before relevance.
- A hook that flatters instead of proving fit.

## Handoff Guidance

Send target-signal uncertainty to the Company Fit Auditor and claim uncertainty to the Evidence Integrity Reviewer.
