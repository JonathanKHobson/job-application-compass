# Metrics And Truth

Cover-letter metrics must be true, explainable, and relevant. A cover letter should never create numbers to sound stronger.

## Truth Rules

- Do not invent metrics.
- Do not create fake precision from vague evidence.
- Do not upgrade partial contribution into sole ownership.
- Do not present old or adjacent experience as current direct experience.
- Do not imply credentials, tools, platforms, clients, relationships, or company knowledge that were not supplied.
- Mark missing facts as `[MISSING INFO: ...]`.

## Metric Statuses

Use these statuses internally when evaluating a metric:

- Verified: exact number appears in supplied evidence or the user confirms it.
- Estimated: calculation path is transparent and the user approves the estimate.
- Needs review: evidence hints at the metric, but the number or scope is uncertain.
- Missing: no number is available.
- Blocked: the request asks for invented, inflated, or unsupported numbers.

## Metric Use In Cover Letters

Use a metric only when it strengthens the proof paragraph and can be defended.

If a number is missing, use non-numeric impact:

- reduced ambiguity
- clarified ownership
- improved handoff quality
- made decision risks visible
- standardized repeatable work
- improved consistency
- increased stakeholder alignment
- reduced manual effort
- created a reusable workflow

## Safe Output Shape

```markdown
## Metric Check
- Status:
- Claim:
- Support:
- Safe cover-letter language:
- Needs verification:
- Do not say:
```
