# Generic Phrase Guardrails

These phrases are warnings for cover-letter drafting and review. They usually signal generic polish instead of proof.

## Risky Phrases

- `I am writing to apply`
- `passionate about`
- `proven track record`
- `results-driven`
- `dynamic`
- `innovative professional`
- `highly motivated`
- `detail-oriented`
- `leveraging cutting-edge`
- `fast-paced environment`
- `team player`
- `wear many hats`
- `uniquely qualified`
- `game changer`
- `thought leader`
- `AI-powered`
- `seamless`
- `robust`
- `synergy`

## Rewrite Pattern

Instead of:

```text
I am writing to apply because I am passionate about your innovative company.
```

Use:

```text
Your posting emphasizes [role problem], which matches my experience turning [supported evidence] into [decision, artifact, or outcome].
```

## Review Questions

- What specific evidence proves the claim?
- What reader problem does this sentence answer?
- Is the company signal verified?
- Could the candidate defend this calmly in an interview?
- Is this phrase doing work, or only adding polish?
