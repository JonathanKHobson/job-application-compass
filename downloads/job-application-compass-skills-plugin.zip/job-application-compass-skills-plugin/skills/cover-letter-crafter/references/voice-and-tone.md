# Voice And Tone

Cover letters should sound like a real person with specific evidence, not a generic professional persona.

## Default Voice

- Warm
- Specific
- Direct
- Reflective
- Outcome-linked
- Confident without inflation

## Good Tone Signals

- Names the problem the role is solving.
- Connects evidence to reader value.
- Uses concrete verbs.
- Leaves room for conversation.
- Avoids exaggerated admiration.
- Avoids over-explaining.

## Strong Verbs

- translated
- clarified
- synthesized
- mapped
- evaluated
- designed
- tested
- facilitated
- documented
- recommended
- improved
- supported
- influenced

## Avoid

- Generic enthusiasm.
- Empty superlatives.
- Inflated ownership.
- Company flattery without evidence.
- A letter that sounds like a resume in paragraph form.
- A letter that sounds like a template with the company name swapped in.

## Voice Repair Pattern

Generic:

```text
I am passionate about joining your innovative team and leveraging my proven track record.
```

Specific:

```text
The role's emphasis on [role problem] fits the work I have done translating [evidence area] into [decision, artifact, or outcome].
```

## Tone Audit Questions

- Is this sentence specific to the target role?
- Is this enthusiasm supported by a real signal?
- Does this phrase add evidence or just polish?
- Could the candidate say this out loud in an interview?
- Is the letter confident without becoming inflated?
