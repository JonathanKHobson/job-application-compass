# Cover Letter Template Index

Choose a template by application context and target role.

## Templates

- `cold-application.md`: default for direct applications with no referral.
- `referral.md`: when a real contact or referral path exists.
- `mission-fit.md`: when the user has verified company mission or product context.
- `product-ux.md`: product, UX, research, design, or customer-experience roles.
- `ai-workflow.md`: AI workflow, automation, prompt systems, or operational AI roles.
- `teaching-learning.md`: education, training, enablement, instructional design, or AI literacy roles.

## Selection Rule

Use the narrowest truthful template. If company context is weak, choose `cold-application.md` and anchor the hook in the role problem instead of invented mission fit.
