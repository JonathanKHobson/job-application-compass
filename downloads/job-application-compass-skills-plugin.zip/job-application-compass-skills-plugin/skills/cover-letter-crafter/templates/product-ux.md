# Product / UX Template

## Use When

- The role involves product, UX research, UX design, customer experience, service design, research operations, or design strategy.

## Structure

1. Opening: product, user, research, or design decision problem.
2. Body: one UX/product proof story using supplied evidence.
3. Bridge: connect artifact, method, or decision to the target role.
4. Close: invite conversation about the product, user, or decision problem.

## Must Not Include

- Tool lists without decisions.
- Unsupported product ownership.
- Visual polish claims without artifact evidence.
- Unverified user or business impact.

## Prompt

```text
Write a product/UX cover letter for [role]. Open on the role's product, user, research, or design decision problem. Use one supplied proof story and connect it to reader value without overstating ownership.
```
