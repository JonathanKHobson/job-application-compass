# Cold Application Template

## Use When

- The user is applying directly.
- No referral or real relationship is involved.
- Company research is thin or unavailable.

## Structure

1. Opening: role-specific problem or team need from the job description.
2. Body: one compact proof paragraph using supplied evidence.
3. Bridge: connect proof to the target role.
4. Close: concise interest and availability.

## Must Not Include

- Generic "I am writing to apply" opening.
- Unsupported company admiration.
- Reused praise from another company.
- Unverified metrics.

## Prompt

```text
Write a concise cold-application cover letter for [role]. Use the job description's core problem as the opening hook. Use only the supplied candidate evidence. If company research is missing, write [MISSING INFO: verified company signal] instead of inventing company fit.
```
