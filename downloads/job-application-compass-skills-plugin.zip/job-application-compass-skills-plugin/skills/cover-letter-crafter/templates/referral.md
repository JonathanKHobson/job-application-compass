# Referral Template

## Use When

- The user has a real referral, contact, or routing path.
- The relationship and ask can be stated truthfully.

## Structure

1. Opening: name the real relationship and specific role.
2. Body: make it easy for the referrer or reader to assess fit with one evidence-backed summary.
3. Bridge: explain why the role is a good match.
4. Close: low-pressure request for routing advice or referral path.

## Must Not Include

- Implied obligation.
- Exaggerated closeness.
- Unverified relationship details.
- Pressure or guilt.
- Auto-send assumptions.

## Prompt

```text
Write a referral-aware cover letter or note for [role]. State the real relationship only as supplied. Keep the ask low-pressure, use one proof story, and do not imply the contact owes a referral.
```
