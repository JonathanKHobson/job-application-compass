# Teaching / Learning Template

## Use When

- The role involves education, training, enablement, curriculum, instructional design, learning experience, or AI literacy.

## Structure

1. Opening: learner, audience, access, confidence, clarity, or curriculum problem.
2. Body: one teaching, training, or learning-design proof story.
3. Bridge: connect the proof to the target learners or program.
4. Close: concise teaching or enablement contribution.

## Must Not Include

- Unsupported learner counts.
- Unsupported institutional claims.
- Generic teaching philosophy.
- Unverified program or curriculum ownership.

## Prompt

```text
Write a teaching or learning-focused cover letter for [role]. Open on the learner or audience problem. Use supplied evidence only, and flag any learner-count or institutional claims that need verification.
```
