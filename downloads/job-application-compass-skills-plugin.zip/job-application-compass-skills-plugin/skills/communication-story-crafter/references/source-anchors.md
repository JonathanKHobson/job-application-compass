# Source Anchors

These sources anchor the skill's core frameworks. Use them as orientation, not
as proof for user-specific claims.

## Communication Style Adaptation

- Everything DiSC, “What Is the Everything DiSC Model?”: https://www.everythingdisc.com/what-is-disc
- DiSC Profile, “The DiSC Styles”: https://www.discprofile.com/what-is-disc/disc-styles
- Insights Discovery: https://www.insights.com/us/products/insights-discovery/

## Rhetoric

- Stanford Encyclopedia of Philosophy, “Aristotle's Rhetoric”: https://plato.stanford.edu/entries/aristotle-rhetoric/
- Purdue OWL, “Using Rhetorical Strategies for Persuasion”: https://owl.purdue.edu/owl/general_writing/academic_writing/establishing_arguments/rhetorical_strategies.html
- Purdue OWL, “Classical Argument”: https://owl.purdue.edu/owl/general_writing/academic_writing/historical_perspectives_on_argumentation/classical_argument.html

## Clarity And Accessibility

- Digital.gov Plain Language: https://digital.gov/guides/plain-language/
- W3C WAI WCAG overview: https://www.w3.org/WAI/standards-guidelines/wcag/

## Skill Structure

- OpenAI API docs, “Skills”: https://developers.openai.com/api/docs/guides/tools-skills
- Agent Skills overview: https://agentskills.io/home
