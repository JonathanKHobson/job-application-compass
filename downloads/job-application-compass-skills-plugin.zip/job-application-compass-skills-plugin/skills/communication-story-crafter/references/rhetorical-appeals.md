# Rhetorical Appeals

Use ethos, logos, pathos, and kairos as practical quality checks.

## The Four Checks

| Appeal | Plain Meaning | Drafting Question |
| --- | --- | --- |
| Ethos | Credibility and character | Why should this reader trust the speaker or source? |
| Logos | Logic and evidence | Does the argument make sense and use adequate proof? |
| Pathos | Emotion, values, and care | Why should the reader care? |
| Kairos | Timing and opportune moment | Why this message, here and now? |

Aristotle's rhetoric is commonly taught through ethos, pathos, and logos. A
practical communication system should also account for kairos because timing
often determines whether a true message lands.

## Balance Meter

```markdown
## Rhetorical Balance
- Ethos: 1-5
- Logos: 1-5
- Pathos: 1-5
- Kairos: 1-5
- Strongest appeal:
- Missing appeal:
- Revision priority:
```

## Practical Use

For a UX research readout:

- Ethos: name method, sample, source, and limits.
- Logos: show the chain from data to implication.
- Pathos: show the human consequence without overdramatizing.
- Kairos: explain what decision window makes the message timely.

For a job-search message:

- Ethos: show a concrete reason for relevance.
- Logos: connect role needs to supplied evidence.
- Pathos: sound interested, human, and specific.
- Kairos: make the ask reasonable for the current relationship stage.

## Misuse Warnings

- Ethos is not credential inflation.
- Logos is not a wall of data.
- Pathos is not manipulation.
- Kairos is not fake urgency.

## Source Anchors

- Stanford Encyclopedia of Philosophy, “Aristotle's Rhetoric”: https://plato.stanford.edu/entries/aristotle-rhetoric/
- Purdue OWL, “Using Rhetorical Strategies for Persuasion”: https://owl.purdue.edu/owl/general_writing/academic_writing/establishing_arguments/rhetorical_strategies.html
- Purdue OWL, “Classical Argument”: https://owl.purdue.edu/owl/general_writing/academic_writing/historical_perspectives_on_argumentation/classical_argument.html
