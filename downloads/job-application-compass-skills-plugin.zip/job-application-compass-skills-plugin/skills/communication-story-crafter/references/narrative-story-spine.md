# Narrative Story Spine

Stories create meaning by linking events, motives, stakes, consequences, and
emotion. In professional communication, a story is not entertainment filler; it
is a way to make evidence graspable.

## Smallest Useful Story

```text
Someone wanted something.
Something got in the way.
Here is what that reveals.
Here is what we should do.
```

## Story Elements

| Element | Professional Translation |
| --- | --- |
| Character | User, customer, team, stakeholder, learner, candidate, audience |
| Goal | What they are trying to do |
| Obstacle | What blocks progress or understanding |
| Stakes | Why it matters |
| Turning point | The insight, contradiction, or evidence pattern |
| Resolution | Recommendation, action, lesson, or next step |

## UX Research Story Spine

```text
Users came in trying to [goal].
They expected [mental model].
But when they reached [moment], they experienced [friction].
This matters because [impact].
The pattern suggests [insight].
We recommend [action].
The decision we need is [ask].
```

## Career Story Spine

```text
I was working in [context].
The problem was [problem].
The constraint was [constraint].
I contributed by [specific action].
The artifact or decision was [proof].
The outcome or learning was [result].
This matters for [target reader] because [relevance].
```

## Story vs. Anecdote

| Anecdote | Evidence-Backed Story |
| --- | --- |
| One interesting example | Representative example connected to a pattern |
| Emotion only | Emotion plus data or context |
| “This happened once” | “This illustrates a recurring issue” |
| Can distort priorities | Clarifies why the pattern matters |

Use stories to illuminate evidence, not replace evidence.
