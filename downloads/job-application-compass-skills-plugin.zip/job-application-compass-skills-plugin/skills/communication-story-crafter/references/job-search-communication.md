# Job-Search Communication

Job search is a sequence of communications, not just a resume and cover letter.

## Common Message Types

- Recruiter initial reply
- Recruiter follow-up after silence
- Hiring manager outreach
- Weak-tie networking message
- Referral request
- Thank-you after interview
- Post-interview follow-up with extra artifact
- Clarification about role scope
- Salary range inquiry
- Withdrawal from process
- Graceful rejection response
- Request for portfolio feedback
- Informational interview request

## Job-Search Message Score

Score 1-5:

- Clear reason for writing
- Specific role, company, or context signal
- Concrete proof or relevance cue
- One low-friction ask
- Appropriate warmth
- Appropriate brevity
- Voice fidelity
- No unsupported claims
- No desperation tone
- Easy next step

## Channel Fit

Email:

- Subject line
- 2-4 short paragraphs
- Context, relevance, and next step

LinkedIn DM:

- No subject line
- 1-2 compact paragraphs
- Lighter tone
- One clear ask

Application note:

- Concise
- Formal enough
- Evidence-focused
- No broad biography

Interview answer:

- Answer the question directly
- Use one story
- Connect to the target role
- End with the point

## Outreach Micro-Artifact Options

Use only when the artifact is real, relevant, and not overwhelming:

- 1-page role-fit memo
- Short case-study link
- Research synthesis sample
- Workflow diagram
- Portfolio page excerpt
- Interview question list
- “What I noticed about this product” note

## Manual-Send Boundary

This skill may draft, audit, and prepare message text. It should not instruct a
host to send automatically or run bulk outreach.
