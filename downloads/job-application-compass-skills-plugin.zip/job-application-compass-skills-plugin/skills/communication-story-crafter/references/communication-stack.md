# Communication Stack

Good communication is audience-shaped meaning. It turns information into
understanding, trust, decision, memory, feeling, alignment, repair, or action.

## The Stack

Use this sequence before drafting:

1. **Intent:** What should the message accomplish?
2. **Audience:** Who receives it, and what do they need to receive it well?
3. **Frame:** What lens makes the information meaningful?
4. **Structure:** What order reduces work for the reader?
5. **Evidence:** What proof will this audience trust?
6. **Style:** What tone, pace, and detail level fit the moment?
7. **Medium:** Where is this message happening?
8. **Feedback loop:** How will we know whether it worked?

## Intent Options

- Inform
- Persuade
- Teach
- Align
- Entertain
- Warn
- Negotiate
- Repair trust
- Motivate
- Summarize
- Ask for a decision

## Framing Options

- Risk: this prevents harm, waste, or failure.
- Opportunity: this unlocks a better path.
- Empathy: this helps people feel understood or supported.
- Efficiency: this saves time or reduces rework.
- Strategic: this connects to a larger priority.
- Quality: this improves reliability or craft.
- Identity: this connects to who the reader wants to be.
- Learning: this makes a complex idea usable.

## Structure Options

- Answer first
- Problem -> evidence -> implication -> recommendation
- Situation -> complication -> question -> answer
- Story -> insight -> action
- Claim -> reason -> evidence -> caveat -> ask
- Before -> after -> bridge
- Observation -> interpretation -> feeling -> need -> request

## Evidence Options

- Data
- Observations
- Quotes
- Artifacts
- Screenshots or examples
- Expert authority
- Benchmarks
- Lived experience
- Case studies
- Cost or risk estimates
- Prior decisions

## Working Rule

Do not start with “make it sound better.” Start with what the message needs to
do, for whom, under what constraints.
