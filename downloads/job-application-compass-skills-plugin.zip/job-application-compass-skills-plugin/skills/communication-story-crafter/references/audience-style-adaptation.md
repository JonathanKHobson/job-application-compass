# Audience And Style Adaptation

Style models are useful as adaptation lenses, not as identity labels. Adapt the
message to what the audience needs in context; do not diagnose the person.

## Common Four-Style Mapping

| Need | Style Shorthand | Give Them | Avoid |
| --- | --- | --- | --- |
| Results | Direct / driver / red | Bottom line, options, tradeoffs, ask | Long setup before the point |
| Connection | Expressive / yellow | Energy, story, possibility, human stakes | Sterile data dumps |
| Harmony | Supportive / green | Shared goals, reassurance, low-blame next step | Abrupt criticism |
| Accuracy | Analytical / blue | Method, evidence, caveats, definitions | Hype or vague claims |

## Named Systems To Reference Carefully

- **Everything DiSC / DiSC:** describes four behavioral styles: Dominance,
  influence, Steadiness, and Conscientiousness.
- **Insights Discovery:** uses four “colour energies”: Fiery Red, Sunshine
  Yellow, Earth Green, and Cool Blue.
- **Thomas Erikson's Surrounded by Idiots:** popularized a red/yellow/green/blue
  communication framing for many readers. Treat it as popular shorthand and
  avoid overclaiming scientific authority.

## Adaptation Templates

Direct / result-focused:

```text
Recommendation: [Do X].
Why now: [Risk or opportunity].
Evidence: [Top 1-3 proof points].
Tradeoff: [Cost or risk].
Decision needed: [Specific ask].
```

Analytical / evidence-focused:

```text
Claim: [Specific finding].
Evidence base: [Data, method, sample, source].
Interpretation: [What it likely means].
Caveats: [What we do not know].
Recommendation: [Action proportional to evidence].
```

Relational / harmony-focused:

```text
Shared goal: [What we all want].
Observation: [Neutral fact].
Impact: [Effect on people or work].
Proposal: [Low-threat next step].
Invitation: [Ask for input].
```

Expressive / story-focused:

```text
Hook: [Human moment or surprising pattern].
Story: [What happened].
Meaning: [Why it matters].
Opportunity: [What becomes possible].
Action: [What we do next].
```

## Source Anchors

- Everything DiSC, “What Is the Everything DiSC Model?”: https://www.everythingdisc.com/what-is-disc
- DiSC Profile, “The DiSC Styles”: https://www.discprofile.com/what-is-disc/disc-styles
- Insights Discovery: https://www.insights.com/us/products/insights-discovery/
