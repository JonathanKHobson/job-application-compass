---
name: communication-story-crafter
description: Craft ethical, audience-aware stories, pitches, messages, presentations, and stakeholder communication using hooks, rhetoric, evidence, voice, and channel-fit.
compatibility: Claude Desktop, Claude Code, Codex, ChatGPT, and other hosts that can use Markdown skills
---

# Communication Story Crafter

Communication Story Crafter helps a host AI turn supplied facts, rough thoughts,
research notes, project evidence, or career material into clear communication
that people can understand, trust, remember, and act on.

Use it for job-search messages, portfolio storytelling, UX research readouts,
stakeholder updates, public posts, teaching material, business proposals,
conflict repair, outreach, and interview story shaping.

This skill is public-facing and generic. It must work only from supplied
context and must not rely on hidden profiles, local paths, unpublished evidence,
or unsupplied personal history.

## Use This Skill When

- The user wants to tell a clearer story about a project, result, lesson, or
  career move.
- The user wants a better opening hook for a post, portfolio case, cover
  letter, email, presentation, or interview answer.
- The user needs to adapt a message for a recruiter, hiring manager, executive,
  UX lead, product manager, engineer, client, student, or collaborator.
- The user wants to sell an idea ethically without overclaiming.
- The user wants to turn messy speech or notes into a coherent message.
- The user asks whether a message has enough credibility, logic, emotion, and
  timing.
- The user needs help with tone, clarity, reader fit, de-escalation, or
  specificity.
- Another writing skill needs story, audience, hook, or rhetorical support.

## First Move

Classify the communication job before drafting:

1. Story or case narrative
2. Public post or thought-leadership draft
3. Job-search message
4. Portfolio, resume, or cover-letter story support
5. UX research or stakeholder readout
6. Teaching or explainer material
7. Business pitch or proposal
8. Sensitive message, conflict repair, or negotiation
9. Communication audit

If the supplied facts are enough, proceed. If a missing fact would materially
change the message, ask for that fact or mark it as `[MISSING INFO: ...]`.

## Core Rules

- Shape communication around intent, audience, frame, structure, evidence,
  style, medium, and feedback loop.
- Use hooks to create relevance, tension, curiosity, or payoff; do not use
  clickbait that the message cannot honestly satisfy.
- Treat story as evidence design, not decoration. A story should clarify a
  pattern, decision, or human stake.
- Use ethos, logos, pathos, and kairos as practical checks: credibility,
  reasoning, emotional relevance, and timing.
- Adapt to communication style preferences without labeling people as fixed
  personality types.
- Preserve truth. Do not invent facts, metrics, titles, roles, outcomes,
  decisions, sources, or lived experience.
- Make uncertainty visible instead of polishing it away.
- Prefer specific proof, clear asks, and reader-shaped structure over generic
  “professional” polish.
- For sensitive messages, reduce heat while preserving the real intent.
- Do not create automated sending, scraping, bulk outreach, or platform
  automation instructions.

## Default Workflow

1. Define the intent: understand, decide, act, feel, trust, align, repair,
   persuade, teach, entertain, or remember.
2. Identify the reader: knowledge level, priorities, constraints, risk,
   authority, trust gap, and available attention.
3. Choose the frame: risk, opportunity, empathy, efficiency, strategy, quality,
   identity, or learning.
4. Choose the structure: answer-first, story-spine, problem-evidence-action,
   claim-reason-proof, before-after-bridge, or repair sequence.
5. Select evidence: data, observations, quotes, artifacts, examples, lived
   experience, benchmark, source, case, or decision.
6. Draft with channel fit: email, LinkedIn, Slack-style message, portfolio,
   resume, cover letter, deck, readout, script, or conversation.
7. Audit: hook payoff, credibility, logic, emotional relevance, timing, clarity,
   voice, reader fit, claim integrity, and ethical persuasion.

## Output Shapes

For a story or pitch:

```markdown
## Communication Strategy
- Intent:
- Audience:
- Frame:
- Hook:
- Proof:
- Ask or payoff:

## Draft

## Why This Works
- Ethos:
- Logos:
- Pathos:
- Kairos:

## Risks Or Missing Proof
```

For a hook set:

```markdown
## Best Hook

## Alternatives
1.
2.
3.

## Hook Pattern Notes
- Pattern:
- Audience promise:
- Proof needed:
- Ethical risk:
```

For a message audit:

```markdown
## Communication Health Snapshot
- Intent:
- Reader:
- Overall read:
- Strongest part:
- Main risk:

## Findings
1. Issue:
   - Why it matters:
   - Fix:

## Revised Version

## Send / Share Readiness
```

## Reference Navigation

| Need | Read |
| --- | --- |
| Use the full communication decision stack | `references/communication-stack.md` |
| Create ethical attention and public-work hooks | `references/public-content-hooks.md` |
| Balance ethos, logos, pathos, and kairos | `references/rhetorical-appeals.md` |
| Adapt style without personality sorting | `references/audience-style-adaptation.md` |
| Build story spine and narrative proof | `references/narrative-story-spine.md` |
| Persuade without manipulation | `references/ethical-persuasion.md` |
| Communicate with stakeholders and decision-makers | `references/stakeholder-communication.md` |
| Improve clarity, accessibility, and visual communication | `references/clarity-accessibility.md` |
| Write job-search, outreach, and interview messages | `references/job-search-communication.md` |
| Preserve voice and remove generic AI writing | `references/voice-ai-sludge-checks.md` |
| Audit messages and choose review modes | `references/message-rubrics.md` |
| Review source anchors for the skill's core frameworks | `references/source-anchors.md` |
| Choose a reusable output format | `templates/template-index.md` |
| Use optional specialist role guidance | `agents/agent.md` |

## Agent Roles

Use the agent files as prompt-role guidance when a communication task benefits
from focused review:

- `agents/communication-strategist.md`: intent, audience, frame, channel, and plan
- `agents/hook-story-architect.md`: hooks, story spine, stakes, and payoff
- `agents/rhetorical-appeals-editor.md`: ethos, logos, pathos, kairos balance
- `agents/audience-adaptation-advisor.md`: reader style and detail adaptation
- `agents/stakeholder-coach.md`: decision, resistance, risk, and influence
- `agents/voice-tone-editor.md`: voice fidelity, tone, warmth, and brevity
- `agents/evidence-integrity-reviewer.md`: claims, proof, uncertainty, and metrics
- `agents/career-story-liaison.md`: portfolio, resume, cover letter, and interview story support
- `agents/conflict-repair-coach.md`: de-escalation, repair, boundary, and negotiation messages

## Stop Conditions

A communication draft is ready for human review when:

- The intent and reader are clear.
- The hook honestly matches the payoff.
- The story or message has a visible structure.
- Credibility, logic, emotional relevance, and timing are addressed.
- Strong claims are supported by supplied evidence.
- Missing facts remain visible.
- The ask or next action is clear.
- Tone fits the stakes and channel.
- Generic filler has been replaced with specific context, proof, or human stakes.
