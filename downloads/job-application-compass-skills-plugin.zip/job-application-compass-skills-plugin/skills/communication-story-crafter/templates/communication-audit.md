# Communication Audit Template

```markdown
## Communication Health Snapshot
- Intent:
- Audience:
- Channel:
- Overall read:
- Strongest part:
- Main risk:

## Findings
1. Issue:
   - Why it matters:
   - Fix:

## Rhetorical Balance
- Ethos:
- Logos:
- Pathos:
- Kairos:

## Revised Version

## Share Readiness
```
