# Job-Search Message Template

```markdown
## Message Strategy
- Recipient:
- Channel:
- Relationship stage:
- Intent:
- Proof to include:
- Tone:
- Risk:

## Draft

## Optional Variant

## Review
- Clear reason:
- Specific context:
- Low-friction ask:
- Unsupported claims:
- Tone risk:
```
