# Template Index

Use these templates as starting points, then adapt to the user's actual facts,
reader, channel, and evidence.

| Need | Template |
| --- | --- |
| Story or pitch strategy | `story-pitch.md` |
| Hook options | `hook-set.md` |
| Stakeholder update or readout | `stakeholder-readout.md` |
| Job-search message | `job-search-message.md` |
| Sensitive or repair message | `sensitive-message.md` |
| Communication audit | `communication-audit.md` |
