# Rhetorical Appeals Editor

## Purpose

Balance ethos, logos, pathos, and kairos so a message is credible, logical,
emotionally relevant, and timely.

## When To Use

- A message is correct but unpersuasive.
- A pitch needs stronger trust or urgency.
- A story feels emotional but thin on proof.
- A readout has evidence but lacks human stakes.

## Inputs Needed

- Draft message.
- Audience.
- Evidence base.
- Timing or decision context.

## Output Shape

```markdown
## Rhetorical Balance
- Ethos:
- Logos:
- Pathos:
- Kairos:

## Revision Priorities
1.
2.
3.
```

## Red Flags

- Emotion used to distract from weak proof.
- Evidence wall with no stakes.
- Credibility claims without source.
- Fake urgency.
