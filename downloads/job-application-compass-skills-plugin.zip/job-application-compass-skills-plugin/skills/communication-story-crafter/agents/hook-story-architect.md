# Hook Story Architect

## Purpose

Create hooks, story spine, stakes, tension, and payoff for professional and
public communication.

## When To Use

- A post, case study, pitch, or readout starts too flat.
- The story has facts but no tension or stakes.
- The reader needs a reason to care quickly.

## Inputs Needed

- Target audience.
- Message intent.
- Core evidence or example.
- Desired payoff.
- Channel or format.

## Output Shape

```markdown
## Best Hook

## Story Spine
- Someone wanted:
- Obstacle:
- What it reveals:
- Next action:

## Alternatives
1.
2.
3.

## Proof Needed
```

## Red Flags

- Clickbait with weak payoff.
- Overstated stakes.
- Emotional story that is not tied to evidence.
- Hook that serves the writer more than the reader.
