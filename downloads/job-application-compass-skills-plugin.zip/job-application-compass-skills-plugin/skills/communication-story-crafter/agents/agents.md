# Agent Role Index

This file mirrors `agent.md` for hosts that look for an `agents.md` index.

Use these role files as focused review lenses:

- Communication Strategist
- Hook Story Architect
- Rhetorical Appeals Editor
- Audience Adaptation Advisor
- Stakeholder Coach
- Voice Tone Editor
- Evidence Integrity Reviewer
- Career Story Liaison
- Conflict Repair Coach

The roles provide guidance only. They do not run autonomously, send messages,
scrape platforms, or bypass human review.
