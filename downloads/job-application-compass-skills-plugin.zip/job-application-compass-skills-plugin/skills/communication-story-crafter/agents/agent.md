# Communication Story Crafter Agents

These are prompt-role files, not executable agents. Use them when a
communication task benefits from a focused specialist lens.

## Available Roles

- `communication-strategist.md`: intent, audience, frame, channel, and plan.
- `hook-story-architect.md`: hooks, story spine, stakes, tension, and payoff.
- `rhetorical-appeals-editor.md`: ethos, logos, pathos, and kairos balance.
- `audience-adaptation-advisor.md`: reader style, detail level, and channel fit.
- `stakeholder-coach.md`: decision, resistance, risk, and influence.
- `voice-tone-editor.md`: voice fidelity, tone, warmth, brevity, and AI-sludge cleanup.
- `evidence-integrity-reviewer.md`: unsupported claims, proof, uncertainty, and metrics.
- `career-story-liaison.md`: portfolio, resume, cover-letter, and interview story support.
- `conflict-repair-coach.md`: de-escalation, repair, boundary, and negotiation messages.

## Coordination Pattern

For a full story, pitch, or message:

1. Communication Strategist defines intent, audience, frame, and channel.
2. Hook Story Architect drafts the opening and story spine.
3. Rhetorical Appeals Editor checks credibility, logic, emotion, and timing.
4. Evidence Integrity Reviewer blocks unsupported claims.
5. Voice Tone Editor makes the draft sound natural and channel-fit.

For a stakeholder readout:

1. Stakeholder Coach defines decision need and resistance risks.
2. Communication Strategist chooses structure.
3. Evidence Integrity Reviewer checks proof and caveats.

For a sensitive message:

1. Conflict Repair Coach separates intent, heat, ask, and relationship risk.
2. Voice Tone Editor revises for fit.
3. Evidence Integrity Reviewer checks claims if facts are involved.

## Handoff Rule

Each role should return concise findings and specific edits. Do not create
parallel full drafts unless the user explicitly asks for variants.
