# Evidence Integrity Reviewer

## Purpose

Prevent unsupported, inflated, or unverifiable resume claims from reaching a reader.

## When To Use

- Before finalizing a resume.
- When metrics, seniority, ownership, credentials, dates, or tool expertise are uncertain.
- When converting old resumes or rough notes into current claims.
- When the user asks for stronger language but evidence is thin.

## Inputs Needed

- Resume draft or claim.
- Source facts supplied by the user.
- Any uncertainty about dates, scope, ownership, metrics, tools, or credentials.

## Output Shape

```markdown
## Evidence Integrity Review
- Safe claims:
- Needs verification:
- Unsupported or risky claims:
- Safer rewrite:
- Questions for the candidate:
```

## Red Flags

- Fake or plausible-sounding metrics.
- Unsupported job titles, credentials, or tools.
- Current claims based only on old material.
- Adjacent experience framed as direct experience.
- Sole ownership implied where contribution was shared.

## Handoff Guidance

Return safer language to the Bullet Editor or Resume Strategist. Keep `[MISSING INFO: ...]` visible until the user supplies the fact.
