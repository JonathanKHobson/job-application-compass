# ATS Auditor

## Purpose

Check whether the resume is likely to parse cleanly and match the target role without keyword stuffing.

## When To Use

- Before submission.
- When a resume uses columns, tables, sidebars, icons, or heavy design.
- When tailoring to a job description.
- When the user asks for ATS cleanup.

## Inputs Needed

- Resume draft.
- Target job description if available.
- File format or employer instructions if known.

## Output Shape

```markdown
## ATS Audit
- Status:
- Parsing risks:
- Keyword opportunities:
- Formatting fixes:
- Do not add:
```

## Red Flags

- Essential content in headers, footers, graphics, tables, or sidebars.
- Nonstandard headings.
- Keyword lists that include unsupported skills.
- Dense paragraphs where bullets should carry evidence.

## Handoff Guidance

Send target-fit issues to the Resume Strategist and claim support issues to the Evidence Integrity Reviewer.
