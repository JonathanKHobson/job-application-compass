# ATS Simple Design

## Best For

- Application portals.
- Conservative industries.
- First-pass recruiter screens.
- Any situation where parsing reliability matters most.

## Structure

```text
Name
Location | Email | Phone | LinkedIn/Portfolio

Summary
Skills
Experience
Selected Projects
Education
Certifications
```

## Rules

- One column.
- Standard headings.
- Plain bullets.
- No icons, photos, charts, tables, or sidebars.
- Keep links visible as text.
- Use consistent date formatting.

## Good Tradeoff

This design is not the most visually distinctive. Its job is to prevent parsing problems and keep the candidate's strongest evidence easy to find.
