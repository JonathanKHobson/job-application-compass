# Portfolio-Leaning Design

## Best For

- Design roles.
- Research roles.
- Writing, content, or communication roles.
- Product, strategy, or project roles where artifacts prove judgment.

## Structure

```text
Name
Target role phrase
Contact and portfolio links

Summary
Relevant Skills
Experience
Selected Case Work
Education
```

## Rules

- Keep the application resume parser-safe.
- Add selected work as text links, not image previews.
- Include case titles only when they clarify fit.
- Describe what each case proves in plain language.
- Avoid turning the resume into a portfolio page.

## Good Tradeoff

This design makes proof-of-work visible without sacrificing the resume's core job: helping the reader understand fit quickly.
