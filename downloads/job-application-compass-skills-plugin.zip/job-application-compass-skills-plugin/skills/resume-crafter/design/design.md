# Resume Design

Resume design should make evidence easier to read. It should not make the resume harder to parse or defend.

## Design Rules

- Start with an ATS-safe submission version.
- Use a human-facing version only when the user needs a polished PDF or networking copy.
- Keep essential content in the main text flow.
- Use clear headings, consistent spacing, and predictable date/title patterns.
- Do not let decoration replace proof.

## Available Design Directions

- `ats-simple.md`: safest default for online applications.
- `hybrid-recruiter.md`: slightly stronger human scan while preserving simple structure.
- `portfolio-leaning.md`: for design, research, creative, or case-based roles where selected work matters.

## Choosing A Direction

Use ATS Simple when:

- The resume will be uploaded into an application portal.
- The employer asks for Word or plain PDF.
- The candidate has no need for visual differentiation.

Use Hybrid Recruiter when:

- A human is likely to read the file directly.
- The candidate has broad experience that needs stronger hierarchy.
- The resume still needs to remain parser-safe.

Use Portfolio Leaning when:

- The target role values artifacts, case studies, research, design, writing, or project proof.
- Links and selected work need to be visible.
- The submission system is not the only reader.
