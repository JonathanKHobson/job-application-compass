# Bullet Rewriting

Resume bullets should make work legible: what changed, what the candidate did, and why it mattered.

## Default Rewrite Steps

1. Identify the claim.
2. Identify the evidence supplied.
3. Choose the strongest truthful verb.
4. Pick a pattern: RAP, PAR, STAR compression, or non-numeric impact.
5. Remove filler.
6. Return 2-3 options with notes about what still needs verification.

## Strong Verb Families

Use verbs that match the actual work:

- Research: interviewed, surveyed, synthesized, mapped, evaluated, tested
- Design: prototyped, redesigned, clarified, structured, documented, iterated
- Analysis: analyzed, modeled, compared, prioritized, forecasted, diagnosed
- Operations: standardized, coordinated, reduced, streamlined, implemented, monitored
- Communication: translated, presented, facilitated, documented, briefed, aligned
- Leadership: led, co-led, mentored, guided, partnered, influenced, recommended

## Weak Bullet Diagnosis

Weak bullets often:

- Describe duties only.
- Start with generic responsibility language.
- List tools without judgment.
- Claim impact without proof.
- Use inflated verbs for partial contribution.
- Hide the audience, artifact, or decision.

## Rewrite Patterns

### Duty To Evidence

Weak:

```text
Responsible for weekly reporting.
```

Stronger:

```text
Produced weekly reporting summaries that clarified open risks, next actions, and decision points for cross-functional stakeholders.
```

### Tool List To Judgment

Weak:

```text
Used spreadsheets, dashboards, and presentation tools.
```

Stronger:

```text
Built dashboard-ready reporting views and executive summaries to help stakeholders compare trends, risks, and next-step options.
```

### Missing Metric To Non-Numeric Impact

Weak:

```text
Improved the process significantly.
```

Stronger:

```text
Reduced process ambiguity by documenting handoffs, clarifying ownership, and creating a repeatable intake workflow.
```

### Overclaim To Accurate Scope

Weak:

```text
Owned the product strategy.
```

Stronger when scope is partial:

```text
Contributed research findings and prioritization recommendations that shaped product strategy discussions.
```

## Bullet Output Contract

When rewriting a bullet, return:

```markdown
## Best Option
- [Bullet]

## Alternatives
- [Bullet]
- [Bullet]

## Support Check
- Supported by supplied facts:
- Needs verification:
- Avoid saying:
```
