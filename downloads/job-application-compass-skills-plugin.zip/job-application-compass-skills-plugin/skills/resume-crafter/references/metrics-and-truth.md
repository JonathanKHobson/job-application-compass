# Metrics And Truth

Resume impact language must be useful without becoming inflated. Numbers are powerful only when they are true, explainable, and defensible.

## Truth Rules

- Do not invent metrics.
- Do not create fake precision from vague evidence.
- Do not upgrade partial contribution into sole ownership.
- Do not present old or adjacent experience as current direct experience.
- Do not imply credentials, tools, platforms, or clients that were not supplied.
- Mark missing facts as `[MISSING INFO: ...]`.

## Metric Statuses

Use these statuses internally when evaluating a metric:

- Verified: exact number appears in supplied evidence or the user confirms it.
- Estimated: calculation path is transparent and the user approves the estimate.
- Needs review: evidence hints at the metric, but the number or scope is uncertain.
- Missing: no number is available.
- Blocked: the request asks for invented, inflated, or unsupported numbers.

## Metric Reconstruction

When a user wants stronger impact language:

1. Look for exact numbers in supplied evidence.
2. If exact numbers are absent, look for a transparent calculation path.
3. If calculation is possible, label it as an estimate and ask for approval before final use.
4. If no metric is supported, write non-numeric impact language.
5. If the user asks for a plausible number without evidence, refuse that part and offer a truthful alternative.

## Non-Numeric Impact Language

Use when metrics are missing or sensitive:

- reduced ambiguity
- clarified ownership
- shortened review cycles
- improved handoff quality
- made decision risks visible
- standardized repeatable work
- improved consistency
- increased stakeholder alignment
- reduced manual effort
- created a reusable workflow

## Safe Output Shape

```markdown
## Metric Check
- Status:
- Claim:
- Support:
- Safe resume language:
- Needs verification:
- Do not say:
```

## Examples

Supported:

```text
Supplied evidence says customer response time fell from 48 hours to 24 hours.
```

Safe language:

```text
Reduced customer response time by 50% by standardizing intake, routing, and follow-up workflows.
```

Missing:

```text
Supplied evidence says the process became easier, but no number is available.
```

Safe language:

```text
Reduced process friction by standardizing intake, clarifying ownership, and documenting repeatable next steps.
```
