# Resume Patterns

Use these patterns to choose the right resume move instead of rewriting everything by habit.

## Dual-Reader Strategy

Every resume has two readers:

- ATS or parser: needs standard headings, readable text, job-aligned keywords, and simple formatting.
- Human recruiter or hiring manager: needs fast positioning, credible proof, and a reason to keep reading.

Use this pattern when targeting a resume to a role. Keep the structure simple enough for parsing, then make the first 10 seconds useful for a person.

## Center Of Gravity

A strong resume has one main story. It can show breadth, but it should not ask the reader to assemble the candidate's identity from scattered fragments.

Use this pattern when the candidate has hybrid experience. Choose one primary role framing, then let adjacent strengths support it.

## RAP Bullet

Default resume bullet pattern:

```text
Result + Action + Problem
```

Use RAP when the impact is known or can be described confidently.

Example shape:

```text
Improved [result] by [action] for [problem/audience/context].
```

## PAR Bullet

Use PAR when the problem context matters:

```text
Problem + Action + Result
```

Example shape:

```text
When [problem], [action], resulting in [result].
```

## STAR Compression

Use STAR when converting interview-style stories into resume bullets:

- Situation: what was happening
- Task: what needed to change
- Action: what the candidate did
- Result: what changed

Compress STAR into one bullet. Do not include all four labels in the resume.

## Evidence-To-Decision

For research, strategy, analysis, product, and operations work, tie methods to decisions:

```text
Used [method/artifact] to inform [decision], reducing [risk/friction/cost] or enabling [outcome].
```

This avoids method lists that do not show judgment.

## Scope Clarifier

When ownership could be overstated, name the real scope:

- Led
- Co-led
- Supported
- Designed
- Facilitated
- Contributed to
- Partnered with
- Produced
- Synthesized
- Recommended

Use the strongest truthful verb.

## Missing Metric Fallback

When the candidate has impact but no verified number, do not invent one. Use observable impact language:

```text
Reduced manual review effort by standardizing intake, clarifying handoffs, and documenting repeatable decision rules.
```

## Anti-Overfit Check

After targeting a resume, ask:

- Did we add only keywords supported by the candidate's evidence?
- Did we preserve the candidate's real center of gravity?
- Would the candidate be comfortable defending every line in an interview?
- Did the resume become stronger, or only more stuffed with job-post language?
