# Resume Quality Rubric

Use this rubric for resume audits and revision passes.

## Rating Scale

- 4: Strong. Ready for final human review.
- 3: Good. Needs light tightening.
- 2: Mixed. Usable, but important weaknesses remain.
- 1: Weak. Major rewrite needed.
- 0: Blocked. Missing core information or contains unsafe claims.

## Criteria

### Target Fit

The resume makes the target role obvious and foregrounds the most relevant evidence.

Check:

- Summary points toward the role.
- Section order matches reader needs.
- Keywords appear naturally and truthfully.
- Adjacent experience is framed honestly.

### Evidence Strength

Strong claims are supported by supplied facts.

Check:

- Bullets include actions, scope, artifacts, decisions, outcomes, or constraints.
- Claims do not imply unsupported seniority or ownership.
- Missing information is visible.
- Sensitive or uncertain details are not overstated.

### Bullet Quality

Bullets are specific, compressed, and outcome-aware.

Check:

- Most bullets begin with strong verbs.
- Each bullet says what changed, what was made, or what decision was enabled.
- Tool names do not replace judgment or impact.
- Repeated verbs and repeated sentence shapes are reduced.

### ATS Readability

The resume can be parsed by common systems.

Check:

- Standard headings are used.
- Text is selectable and linear.
- Tables, icons, columns, sidebars, images, headers, and footers are avoided for the submission version.
- Dates, titles, organizations, and locations are easy to identify.

### Human Scan

A human reader can understand the candidate quickly.

Check:

- The first third of the resume has the strongest role-relevant proof.
- The summary is not a string of adjectives.
- Skills are grouped and not bloated.
- Experience entries show progression, contribution, and context.

### Integrity And Defensibility

The candidate can defend every line in an interview.

Check:

- Metrics are verified or clearly marked for review.
- No fake precision is introduced.
- Old, adjacent, or partial experience is not presented as current direct experience.
- Gaps are not hidden behind vague language.

## Audit Output

Use this compact format:

```markdown
## Resume Health Snapshot
- Target fit: [0-4]
- Evidence strength: [0-4]
- Bullet quality: [0-4]
- ATS readability: [0-4]
- Human scan: [0-4]
- Integrity: [0-4]
- Top priority:

## Highest-Impact Fixes
1. [Fix]
2. [Fix]
3. [Fix]

## Do Not Change Yet
- [Anything that is already working or should not be broadened]
```
